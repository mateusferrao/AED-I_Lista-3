/*
9a) 2;
9b) 3;

Algoritmo 1 - 9c) 2,8;
Algoritmo 2 - 9c) 1,4;

Algoritmo 1 - 9d) n,n-1,n,((pares ate n)+1)+n
Algoritmo 2 - 9d) n-1,(n-(n%2))/2,






*/
